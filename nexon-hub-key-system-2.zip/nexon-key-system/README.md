# Nexon Hub Key System starter

Responsive black/blue key page with a Node/Express backend and server-side Cloudflare Turnstile validation. It intentionally does **not** release `NexonHub2026` yet: a Linkvertise redirect by itself does not prove that the visitor completed all required tasks. Connect a supported Linkvertise completion verification mechanism in `server.js` before enabling key release.

## Configure
1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Set `LINKVERTISE_URL` to your real Linkvertise URL.
4. In the Cloudflare dashboard, create a Turnstile widget for your site hostname. Put its public site key in `TURNSTILE_SITE_KEY` and secret in `TURNSTILE_SECRET_KEY`.
5. Set `TURNSTILE_ALLOWED_HOSTNAMES` to the exact hostname(s) returned by Siteverify.
6. Run `npm install`, then `npm start`.
7. Deploy on a Node.js host with HTTPS and configure the environment variables there. Never commit `.env` or expose the Turnstile secret.

## Important integration note
`POST /api/redeem` verifies Turnstile with Cloudflare Siteverify and validates the returned hostname. It then deliberately returns a setup error until a genuine Linkvertise completion verifier is implemented. Do not treat a query parameter, a browser redirect, or a CAPTCHA pass as proof of ad completion.

## Key security
A fixed key embedded in client-side JavaScript can be extracted by visitors. If you keep the fixed key `NexonHub2026`, understand it can be shared and cannot be made secret. Stronger enforcement requires unique server-issued tokens and a matching server-side check in your loader.
