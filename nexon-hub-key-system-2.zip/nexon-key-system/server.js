require('dotenv').config();
const express = require('express');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
app.disable('x-powered-by');
app.use(express.json({ limit: '20kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }));

app.get('/api/config', (_req, res) => {
  const url = process.env.LINKVERTISE_URL || '';
  const safeUrl = /^https:\/\//i.test(url) && !url.includes('PASTE_YOUR') ? url : '';
  res.json({ siteKey: process.env.TURNSTILE_SITE_KEY || '', linkvertiseUrl: safeUrl });
});

async function verifyTurnstile(token, remoteIp) {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret || !token || token.length > 2048) return false;
  const body = new URLSearchParams({ secret, response: token });
  if (remoteIp) body.set('remoteip', remoteIp);
  try {
    const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body
    });
    if (!response.ok) return false;
    const result = await response.json();
    if (!result.success) return false;
    const allowed = (process.env.TURNSTILE_ALLOWED_HOSTNAMES || '')
      .split(',').map(x => x.trim().toLowerCase()).filter(Boolean);
    if (!allowed.length || !result.hostname || !allowed.includes(String(result.hostname).toLowerCase())) return false;
    return true;
  } catch (_err) { return false; }
}

app.post('/api/redeem', async (req, res) => {
  const { turnstileToken } = req.body || {};
  const passedCaptcha = await verifyTurnstile(turnstileToken, req.ip);
  if (!passedCaptcha) return res.status(400).json({ error: 'CAPTCHA verification failed. Please try again.' });

  // IMPORTANT: A return/redirect from Linkvertise is not proof that ad steps were completed.
  // Do not issue the key until you connect an official/supported Linkvertise completion
  // verification mechanism here. Do not accept a user-supplied query parameter as proof.
  if (process.env.LINKVERTISE_VERIFICATION_ENABLED !== 'true') {
    return res.status(503).json({ error: 'CAPTCHA passed, but Linkvertise completion verification is not configured yet.' });
  }

  // TODO: Replace this guard with the real server-side Linkvertise completion verifier.
  // Keep key release server-side. Never move the fixed key into public JavaScript.
  return res.status(503).json({ error: 'Linkvertise verifier adapter must be implemented before keys can be issued.' });
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`Nexon Hub key system listening on port ${PORT}`));
